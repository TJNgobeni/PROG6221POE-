﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        RecipeManager manager = new RecipeManager();
        manager.Run();
    }
}

public class Ingredient
{
    public string Name { get; set; }
    public double Quantity { get; set; }
    public string Unit { get; set; }
    public double Calories { get; set; }
    public string FoodGroup { get; set; }
    public double OriginalQuantity { get; private set; }

    public Ingredient(string name, double quantity, string unit, double calories, string foodGroup)
    {
        Name = name;
        Quantity = quantity;
        Unit = unit;
        Calories = calories;
        FoodGroup = foodGroup;
        OriginalQuantity = quantity;
    }

    public void Scale(double factor)
    {
        Quantity = OriginalQuantity * factor;
    }

    public override string ToString()
    {
        return $"{Quantity} {Unit} of {Name} ({Calories} calories, {FoodGroup})";
    }
}

public class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients { get; private set; }
    public List<string> Steps { get; private set; }

    public Recipe()
    {
        Ingredients = new List<Ingredient>();
        Steps = new List<string>();
    }

    public void AddIngredient(Ingredient ingredient)
    {
        Ingredients.Add(ingredient);
    }

    public void AddStep(string step)
    {
        Steps.Add(step);
    }

    public void ScaleRecipe(double factor)
    {
        foreach (var ingredient in Ingredients)
        {
            ingredient.Scale(factor);
        }
    }

    public double CalculateTotalCalories()
    {
        return Ingredients.Sum(ingredient => ingredient.Calories * ingredient.Quantity);
    }

    public void Display()
    {
        Console.WriteLine($"Recipe Name: {Name}\n");
        Console.WriteLine("Ingredients:");
        foreach (var ingredient in Ingredients)
        {
            Console.WriteLine(ingredient);
        }
        Console.WriteLine("\nSteps:");
        int stepNumber = 1;
        foreach (var step in Steps)
        {
            Console.WriteLine($"{stepNumber++}. {step}");
        }

        double totalCalories = CalculateTotalCalories();
        Console.WriteLine($"\nTotal Calories: {totalCalories}");
        if (totalCalories > 300)
        {
            Console.WriteLine("Warning: Total calories exceed 300!");
        }
    }
}

public class RecipeManager
{
    private List<Recipe> recipes;
    private Recipe currentRecipe;

    public RecipeManager()
    {
        recipes = new List<Recipe>();
    }

    public void Run()
    {
        bool running = true;
        while (running)
        {
            Console.WriteLine("Choose an option: [N]ew recipe, [A]dd details, [S]cale, [D]isplay, [L]ist, [E]xit");
            string input = Console.ReadLine().ToUpper();

            switch (input)
            {
                case "N":
                    CreateNewRecipe();
                    break;
                case "A":
                    AddRecipeDetails();
                    break;
                case "S":
                    ScaleRecipe();
                    break;
                case "D":
                    currentRecipe?.Display();
                    break;
                case "L":
                    ListRecipes();
                    break;
                case "E":
                    running = false;
                    break;
                default:
                    Console.WriteLine("Invalid option, try again.");
                    break;
            }
        }
    }

    private void CreateNewRecipe()
    {
        Console.Write("Enter recipe name: ");
        string name = Console.ReadLine();
        currentRecipe = new Recipe() { Name = name };
        recipes.Add(currentRecipe);
        Console.WriteLine("New recipe started.");
    }

    private void AddRecipeDetails()
    {
        if (currentRecipe == null)
        {
            Console.WriteLine("Please create a new recipe first.");
            return;
        }

        Console.Write("Enter the number of ingredients: ");
        int numIngredients = int.Parse(Console.ReadLine());
        for (int i = 0; i < numIngredients; i++)
        {
            Console.Write($"Enter ingredient {i + 1} name: ");
            string name = Console.ReadLine();
            Console.Write("Enter quantity: ");
            double quantity = double.Parse(Console.ReadLine());
            Console.Write("Enter unit of measure: ");
            string unit = Console.ReadLine();
            Console.Write("Enter calories: ");
            double calories = double.Parse(Console.ReadLine());
            Console.Write("Enter food group: ");
            string foodGroup = Console.ReadLine();
            currentRecipe.AddIngredient(new Ingredient(name, quantity, unit, calories, foodGroup));
        }

        Console.Write("Enter the number of steps: ");
        int numSteps = int.Parse(Console.ReadLine());
        for (int i = 0; i < numSteps; i++)
        {
            Console.Write($"Enter step {i + 1} description: ");
            string step = Console.ReadLine();
            currentRecipe.AddStep(step);
        }
    }

    private void ScaleRecipe()
    {
        if (currentRecipe == null)
        {
            Console.WriteLine("Please create a new recipe first.");
            return;
        }

        Console.Write("Enter scale factor (0.5, 2, 3): ");
        double factor = double.Parse(Console.ReadLine());
        currentRecipe.ScaleRecipe(factor);
        Console.WriteLine($"Recipe scaled by a factor of {factor}.");
    }

    private void ListRecipes()
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("No recipes available.");
            return;
        }

        var sortedRecipes = recipes.OrderBy(r => r.Name).ToList();
        Console.WriteLine("Recipes:");
        for (int i = 0; i < sortedRecipes.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {sortedRecipes[i].Name}");
        }

        Console.Write("Choose a recipe to display: ");
        int choice = int.Parse(Console.ReadLine());
        if (choice >= 1 && choice <= sortedRecipes.Count)
        {
            currentRecipe = sortedRecipes[choice - 1];
            currentRecipe.Display();
        }
        else
        {
            Console.WriteLine("Invalid choice.");
        }
    }
}

// Unit Test for Total Calorie Calculation
public class RecipeTests
{
    public void TestTotalCalories()
    {
        // Arrange
        var recipe = new Recipe();
        recipe.AddIngredient(new Ingredient("Sugar", 100, "grams", 387, "Carbohydrates"));
        recipe.AddIngredient(new Ingredient("Butter", 50, "grams", 717, "Fats"));

        // Act
        double totalCalories = recipe.CalculateTotalCalories();

        // Assert
        if (totalCalories != 1104)
        {
            throw new Exception("Total calorie calculation test failed.");
        }
        else
        {
            Console.WriteLine("Total calorie calculation test passed.");
        }
    }
}