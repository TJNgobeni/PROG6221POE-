public class RecipeTests
{
    [Test]
    public void TestTotalCalories()
    {
        // Arrange
        var recipe = new Recipe();
        recipe.AddIngredient(new Ingredient("Sugar", 100, "grams", 3.87, "Carbohydrates"));
        recipe.AddIngredient(new Ingredient("Butter", 50, "grams", 7.17, "Fats"));

        // Act
        double totalCalories = recipe.CalculateTotalCalories();

        // Assert
        Assert.AreEqual(580.5, totalCalories);
    }

    [Test]
    public void TestCaloriesExceededEvent()
    {
        // Arrange
        var recipe = new Recipe();
        recipe.AddIngredient(new Ingredient("Sugar", 100, "grams", 3.87, "Carbohydrates"));
        recipe.AddIngredient(new Ingredient("Butter", 50, "grams", 7.17, "Fats"));
        bool eventTriggered = false;

        // Attach event handler
        recipe.OnCaloriesExceeded += (sender, e) => eventTriggered = true;

        // Act
        recipe.Display();

        // Assert
        Assert.IsTrue(eventTriggered);
    }
