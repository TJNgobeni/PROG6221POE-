﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        RecipeManager manager = new RecipeManager();
        manager.Run();
    }
}

public class Ingredient
{
    public string Name { get; set; }
    public double Quantity { get; set; }
    public string Unit { get; set; }
    public double OriginalQuantity { get; private set; }

    public Ingredient(string name, double quantity, string unit)
    {
        Name = name;
        Quantity = quantity;
        OriginalQuantity = quantity;
        Unit = unit;
    }

    public void Scale(double factor)
    {
        Quantity = OriginalQuantity * factor;
    }

    public void Reset()
    {
        Quantity = OriginalQuantity;
    }

    public override string ToString()
    {
        return $"{Quantity} {Unit} of {Name}";
    }
}

public class Recipe
{
    public string Name { get; set; } // Recipe name property
    public List<Ingredient> Ingredients { get; private set; }
    public List<string> Steps { get; private set; }

    public Recipe()
    {
        Ingredients = new List<Ingredient>();
        Steps = new List<string>();
    }

    public void AddIngredient(Ingredient ingredient)
    {
        Ingredients.Add(ingredient);
    }

    public void AddStep(string step)
    {
        Steps.Add(step);
    }

    public void ScaleRecipe(double factor)
    {
        foreach (var ingredient in Ingredients)
        {
            ingredient.Scale(factor);
        }
    }

    public void ResetQuantities()
    {
        foreach (var ingredient in Ingredients)
        {
            ingredient.Reset();
        }
    }

    public void Clear()
    {
        Ingredients.Clear();
        Steps.Clear();
    }

    public void Display()
    {
        Console.WriteLine($"Recipe Name: {Name}\n"); // Display the recipe name
        Console.WriteLine("Ingredients:");
        foreach (var ingredient in Ingredients)
        {
            Console.WriteLine(ingredient);
        }
        Console.WriteLine("\nSteps:");
        int stepNumber = 1;
        foreach (var step in Steps)
        {
            Console.WriteLine($"{stepNumber++}. {step}");
        }
    }
}

public class RecipeManager
{
    private Recipe currentRecipe;

    public void Run()
    {
        bool running = true;
        while (running)
        {
            Console.WriteLine("Choose an option: [N]ew recipe, [A]dd details, [S]cale, [R]eset, [D]isplay, [C]lear, [E]xit");
            string input = Console.ReadLine().ToUpper();

            switch (input)
            {
                case "N":
                    Console.Write("Enter recipe name: "); // Prompt for recipe name
                    string name = Console.ReadLine();
                    currentRecipe = new Recipe() { Name = name };
                    Console.WriteLine("New recipe started.");
                    break;
                case "A":
                    AddRecipeDetails();
                    break;
                case "S":
                    ScaleRecipe();
                    break;
                case "R":
                    currentRecipe.ResetQuantities();
                    Console.WriteLine("Quantities reset to original.");
                    break;
                case "D":
                    currentRecipe.Display();
                    break;
                case "C":
                    currentRecipe.Clear();
                    Console.WriteLine("Recipe cleared.");
                    break;
                case "E":
                    running = false;
                    break;
                default:
                    Console.WriteLine("Invalid option, try again.");
                    break;
            }
        }
    }

    private void AddRecipeDetails()
    {
        Console.Write("Enter the number of ingredients: ");
        int numIngredients = int.Parse(Console.ReadLine());
        for (int i = 0; i < numIngredients; i++)
        {
            Console.Write($"Enter ingredient {i+1} name: ");
            string name = Console.ReadLine();
            Console.Write($"Enter quantity: ");
            double quantity = double.Parse(Console.ReadLine());
            Console.Write($"Enter unit of measure: ");
            string unit = Console.ReadLine();
            currentRecipe.AddIngredient(new Ingredient(name, quantity, unit));
        }

        Console.Write("Enter the number of steps: ");
        int numSteps = int.Parse(Console.ReadLine());
        for (int i = 0; i < numSteps; i++)
        {
            Console.Write($"Enter step {i+1} description: ");
            string step = Console.ReadLine();
            currentRecipe.AddStep(step);
        }
    }

    private void ScaleRecipe()
    {
        Console.Write("Enter scale factor (0.5, 2, 3): ");
        double factor = double.Parse(Console.ReadLine());
        currentRecipe.ScaleRecipe(factor);
        Console.WriteLine($"Recipe scaled by a factor of {factor}.");
    }
}