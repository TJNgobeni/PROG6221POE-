﻿using System.Windows;
using RecipeManagerWPF.Models;

namespace RecipeManagerWPF
{
    public partial class ScaleRecipeWindow : Window
    {
        private Recipe currentRecipe;

        public ScaleRecipeWindow(Recipe recipe)
        {
            InitializeComponent();
            currentRecipe = recipe;
        }

        private void Scale_Click(object sender, RoutedEventArgs e)
        {
            double factor = double.Parse(ScaleFactorTextBox.Text);
            currentRecipe.ScaleRecipe(factor);
            MessageBox.Show($"Recipe scaled by a factor of {factor}.");
            Close();
        }
    }
}