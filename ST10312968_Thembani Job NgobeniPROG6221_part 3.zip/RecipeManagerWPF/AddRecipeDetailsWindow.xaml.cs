﻿using System.Windows;
using RecipeManagerWPF.Models;

namespace RecipeManagerWPF
{
    public partial class AddRecipeDetailsWindow : Window
    {
        private Recipe currentRecipe;

        public AddRecipeDetailsWindow(Recipe recipe)
        {
            InitializeComponent();
            currentRecipe = recipe;
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            string name = IngredientNameTextBox.Text;
            double quantity = double.Parse(QuantityTextBox.Text);
            string unit = UnitTextBox.Text;
            double calories = double.Parse(CaloriesTextBox.Text);
            string foodGroup = FoodGroupTextBox.Text;
            currentRecipe.AddIngredient(new Ingredient(name, quantity, unit, calories, foodGroup));
            MessageBox.Show("Ingredient added.");
        }

        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            string step = StepDescriptionTextBox.Text;
            currentRecipe.AddStep(step);
            MessageBox.Show("Step added.");
        }

        private void Done_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
