﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using RecipeManagerWPF.Models;

namespace RecipeManagerWPF
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes;
        private Recipe currentRecipe;

        public MainWindow()
        {
            InitializeComponent();
            recipes = new List<Recipe>();
        }

        private void CreateNewRecipe_Click(object sender, RoutedEventArgs e)
        {
            string name = RecipeNameTextBox.Text;
            currentRecipe = new Recipe() { Name = name };
            recipes.Add(currentRecipe);
            MessageBox.Show("New recipe started.");
        }

        private void AddRecipeDetails_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe == null)
            {
                MessageBox.Show("Please create a new recipe first.");
                return;
            }

            var addDetailsWindow = new AddRecipeDetailsWindow(currentRecipe);
            addDetailsWindow.ShowDialog();
        }

        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe == null)
            {
                MessageBox.Show("Please create a new recipe first.");
                return;
            }

            var scaleRecipeWindow = new ScaleRecipeWindow(currentRecipe);
            scaleRecipeWindow.ShowDialog();
        }

        private void DisplayRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (currentRecipe != null)
            {
                RecipeDetailsTextBlock.Text = currentRecipe.ToString();
            }
        }

        private void ListRecipes_Click(object sender, RoutedEventArgs e)
        {
            RecipesListView.ItemsSource = recipes.OrderBy(r => r.Name).ToList();
        }

        private void FilterRecipes_Click(object sender, RoutedEventArgs e)
        {
            string ingredientName = FilterIngredientTextBox.Text;
            var filteredRecipes = recipes.Where(r => r.Ingredients.Any(i => i.Name.Contains(ingredientName, StringComparison.OrdinalIgnoreCase))).ToList();
            RecipesListView.ItemsSource = filteredRecipes;
        }
    }
}