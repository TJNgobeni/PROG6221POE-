﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeManagerWPF.Models
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; private set; }
        public List<string> Steps { get; private set; }

        public Recipe()
        {
            Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        }

        public void AddIngredient(Ingredient ingredient)
        {
            Ingredients.Add(ingredient);
        }

        public void AddStep(string step)
        {
            Steps.Add(step);
        }

        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Scale(factor);
            }
        }

        public double CalculateTotalCalories()
        {
            return Ingredients.Sum(ingredient => ingredient.Calories * ingredient.Quantity);
        }

        public override string ToString()
        {
            string recipeDetails = $"Recipe Name: {Name}\n\nIngredients:\n";
            foreach (var ingredient in Ingredients)
            {
                recipeDetails += $"{ingredient}\n";
            }
            recipeDetails += "\nSteps:\n";
            int stepNumber = 1;
            foreach (var step in Steps)
            {
                recipeDetails += $"{stepNumber++}. {step}\n";
            }

            double totalCalories = CalculateTotalCalories();
            recipeDetails += $"\nTotal Calories: {totalCalories}";
            if (totalCalories > 300)
            {
                recipeDetails += "\nWarning: Total calories exceed 300!";
            }
            return recipeDetails;
        }
    }
}